# SS1-PROJECT-
<h1>Designing and editing a simple calculator </h1><br><br>
<h2>correct the errors in plus, minus, multiplication and division buttons</h2>

step 1 go to Google Play store and download the application droidedit<br>
step 2 go to Google Chrome and install the given link <br>
step 3 download the calc.html file <br>
step 4 go to your phone folder and locate the downloaded file hold on it until you find out that it is selected then click the three dot and select Open with Chrome to view the calculator and check its operations <br>
step 5 repeat step four but this time select Open with droidedit
so that you can start editing the file <br>
step 6 as at this point open your screen recorder to record your actions while editing and testing the calculator file<br>
step 7 locate the name Paschal and edit it to your own name<br>
step 8 locate   <pre><code>
static addAddition() {
    Calculator.setOperation('+', '-');
}

static addSubtraction() {
    Calculator.setOperation('-', '+');
}

static addMultiplication() {
    Calculator.setOperation('*', '/');
}

static addDivision() {
    Calculator.setOperation('/', '*');
}
    </code></pre> then make it rhyme<br>
step 9 save then and head back to your Chrome browser <br>
step 10 test the operation and check if the plus and minus button has been corrected<br>
stop the video and send it(the screen recorded video) to your teacher (me) on WhatsApp on 09153105037
